package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;
import javax.validation.Valid;

import com.gel.ms.api.domain.GeneralCoverageDetails;
import com.gel.ms.api.domain.GeneralInsuranceView;
import com.gel.ms.api.domain.GeneralPolicyDetails;
import com.gel.ms.api.domain.GeneralVehicleInformation;
import com.income.ms.api.core.exception.GlobalApiException;

public interface GeneralPolicyService {

  /**
   * This returns Coverage Details
   *
   * @param request
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  GeneralCoverageDetails getCoverageDetails(@Valid GeneralInsuranceView request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This returns Policy Details
   *
   * @param request
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  GeneralPolicyDetails getPolicyDetails(@Valid GeneralInsuranceView request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This return the Vehicle information.
   *
   * @return Vehicle information
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  GeneralVehicleInformation getVehicleInfo(GeneralInsuranceView request, Map<String, String> header)
      throws GlobalApiException, IOException;
}
