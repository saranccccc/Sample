package com.income.ms.api.core.sysinterface;

import com.income.ms.api.core.enums.SystemEnum;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.interfaces.AgentProfileService;
import com.income.ms.api.core.interfaces.AwardsService;
import com.income.ms.api.core.interfaces.LeadService;
import com.income.ms.api.core.interfaces.OpportunityService;

public abstract class AgentAbstractFactory {

  public abstract AgentProfileService getAgentProfileService(SystemEnum systemEnum)
      throws GlobalApiException;

  public abstract AwardsService getAwardsService(SystemEnum systemEnum) throws GlobalApiException;

  public abstract LeadService getLeadService(SystemEnum systemEnum) throws GlobalApiException;

  public abstract OpportunityService getOppService(SystemEnum systemEnum) throws GlobalApiException;

}
