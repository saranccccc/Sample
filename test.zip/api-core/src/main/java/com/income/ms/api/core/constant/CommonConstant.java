package com.income.ms.api.core.constant;

public class CommonConstant {

  public static final String CDH_DOMAIN_PACKAGE = "com.income.ms.api.domain.cdh";

  public static final String CORE_PACKAGE = "com.income.ms.api.*";
  public static final String CORE_PACKAGE_EXACT = "com.income.ms.api";
  public static final String PRODUCES = "application/json";

  public static final String GROUP_NAME = "public-api";
  public static final String PREDICATE_POSTS = "/api/posts.*";
  public static final String PREDICATRE_APIS = "/gel/api.*";
  public static final String API_INFO_TERMS_OF_SERVICE_URL = "http://income.com";
  public static final String API_INFO_CONTACT_NAME = "";
  public static final String API_INFO_CONTACT_EMAIL = "";
  public static final String API_INFO_CONTACT_URL = "";
  public static final String API_INFO_LICENSE = "";
  public static final String API_INFO_LICENSE_URL = "";
  public static final String API_INFO_VERSION = "1.0";
  public static final String ERROR = "Error";
  public static final String MSP_ERROR_STATUS = "1";

  public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
  public static final String FORBIDDEN =
      "The server understood the request, but is refusing it or the access is not allowed";
  public static final String NOT_FOUND = "There is no resource behind the URI";
  public static final String OK = "Everything is working";
  public static final String BAD_REQUEST = "The request was invalid or cannot be served";

  public static final String TIMEOUT_ERROR_CODE = "MS5000";
  public static final String TIMEOUT_ERROR_DESCRIPTION = "Provider timed out.";
  public static final String VALIDATION_ERROR_CODE = "MS5001";
  public static final String COUNTRY_MISS_CODE = "MS5002";
  public static final String COUNTRY_MISS_DESC = "Country is missing in headers";
  public static final String PROVIDER_MISS_CODE = "MS5003";
  public static final String PROVIDER_MISS_DESC = "Provider is missing in headers";
  public static final String EXE_UNCAUGHT_CODE = "MS5004";
  public static final String EXE_UNCAUGHT_DESC = "Error occured Please try again";

  public static final String NO_ADAPTER_FOUND = "No Adapter found.";

  public static final String VALIDATION_FAILED = "Mandatory fields are missing";
  public static final String FOR_THE_FIELD = " for the field ";

  public static final String CACHE_NAME = "ehcache";

  public static final String HYPEN = "-";
  public static final String NON_NULL = "NON_NULL";

  public static final String MSP_SOURCE = "MSAPI";

  public static final String COUNTRY_CODE = "countrycode";
  public static final String PROVIDER_CODE = "providerorgcode";
  public static final String RRNO = "reqrefnumber";
  public static final String CLIENT_CODE = "clientorgcode";
  public static final String TIMESTAMP = "timestamp";
  public static final String RRNO_RES = "ReqRefNumber";

  public static final String REST_SERVICE_URI = "restServiceUri";
  public static final String HTTP_METHOD = "httpMethod";
  public static final String HTTP_ENTITY = "httpEntity";

  public static final String COUNTRY = "/${app.country.instance}";

  public static final String LEAD_PACK = CORE_PACKAGE_EXACT + ".agent.lead.controller";
  public static final String OPP_PACK = CORE_PACKAGE_EXACT + ".agent.opportunity.controller";
  public static final String REPORTS_PACK = CORE_PACKAGE_EXACT + ".agent.awards.controller";
  public static final String CUS_PRO_PACK = CORE_PACKAGE_EXACT + ".customer.profile.controller";
  public static final String CUS_PORT_PACK = CORE_PACKAGE_EXACT + ".customer.portfolio.controller";
  public static final String CUS_CLA_PACK = CORE_PACKAGE_EXACT + ".ah.health.policy.controller";
  public static final String AGT_PRO_PACK = CORE_PACKAGE_EXACT + ".agent.profile.controller";
  public static final String LIFE_PACK = CORE_PACKAGE_EXACT + ".life.policy.controller";
  public static final String GI_PACK = CORE_PACKAGE_EXACT + ".general.controller";
  public static final String LIFE_GOVT_SCM_PACK = CORE_PACKAGE_EXACT + ".life.govtscheme.policy.controller";
  public static final String LIFE_PROP_PACK = CORE_PACKAGE_EXACT + ".life.proposal.controller";
  public static final String LIFE_GOVT_SCM_PACK_PROP = CORE_PACKAGE_EXACT + ".life.govtscheme.proposal.controller";

  public static final String AGT_PRO = "agentProfile";
  public static final String HEALTH_POL_CLA = "healthPolicy";
  public static final String CUS_PRO = "customerProfile";
  public static final String CUS_PORT = "customerPortfolio";
  public static final String LEAD_INFO = "leadInfo";
  public static final String CRE_LEAD_INFO = "createLeadInfo";
  public static final String UPD_LEAD_INFO = "updateLeadInfo";
  public static final String OPP_INFO = "opportunityInfo";
  public static final String CRE_OPP_INFO = "createOpportunityInfo";
  public static final String UPD_OPP_INFO = "updateOpportunityInfo";
  public static final String AWARDS_INFO = "awardsInfo";
  public static final String LIFE = "lifePol";
  public static final String GEN_INSURANCE = "generalInsurance";
  public static final String AGENT_ROLE = "agentRoleInformation";
  public static final String LIFE_PROP = "lifeProp";
  public static final String LIFE_GOVT_SCM = "lifeGovtScmPol";
  public static final String LIFE_GOVT_SCM_PROP = "lifeGovtScmProp";

  public static final String DATE_FORMAT_1 = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

  public static final String MSP_CUS = "customer";
  public static final String MSP_AGENT = "agent";
  public static final String MSP_LIFE = "life";
  public static final String ACCIDENT_HEALTH = "accident-health";
  public static final String MSP_GEN_INSURANCE = "general";

  public static final String MSP_NAME_KEY = "spring.application.name";

  public static final String HTTP_REST = "httpRestTemplate";
  public static final String HTTPS_REST = "httpsRestTemplate";
  public static final String NOOP_REST = "noopRestTemplate";
  public static final String HTTPS = "https";
  public static final String EMPTY_STRING = "";

  public static final String MQ_REQUEST_FROM = "requestFrom";
  public static final String MQ_END_POINT = "direct:mqEndPoint";
  public static final String MQ_ROUTE_ID = "mqRouteId";
  public static final String MQ_INPUT = "mqInput";

  public static final String GELS_DM_OBJ = "com.income.ms.api.domain.iaaxml47.ObjectFactory";
  public static final String CDH_DOM_OBJ = "com.income.ms.api.domain.cdh.ObjectFactory";

  public static final String SYSTEM_INFO = "sysInfo";

  public static final String ENQUIRY = "E";
  public static final String CREATE = "C";
  public static final String UPDATE = "U";

  public static final String NO = "N";
  public static final String YES = "Y";
  public static final String ROLE_DR = "DR";

  public static final String UPDATE_LEAD_STATUS = "/*/*/*/*/update/*";
  public static final String AWARDS_UPDATE = "/*/*/*/*/update";
  public static final String AWARDS_CREATE = "/*/*/*/*/create";
  public static final String DETAILS = "/*/*/*/*/details";
  public static final String SUMMARY = "/*/*/*/*/summary";
  public static final String COUNT = "/*/*/*/*/count";
}
