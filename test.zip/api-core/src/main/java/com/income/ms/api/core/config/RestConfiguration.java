package com.income.ms.api.core.config;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import org.apache.http.client.HttpClient;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.exception.GlobalApiException;

@Configuration
public class RestConfiguration {

  /**
   * mspkeystore path
   */
  @Value("${app.mspKeyStore}")
  private String mspKeyStore;

  /**
   * mspkeystore Password
   */
  @Value("${app.mspKeyStorePass}")
  private String mspKeyStorePass;

  @Bean
  @Qualifier(value=CommonConstant.HTTP_REST)
  public RestTemplate httpRestTemplate() throws GlobalApiException {
    return new RestTemplate();
  }

  @Bean
  @Qualifier(value=CommonConstant.HTTPS_REST)
  public RestTemplate httpsRestTemplate() throws GlobalApiException, KeyManagementException,
  UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException,
  FileNotFoundException, IOException {

    KeyStore keystore = KeyStore.getInstance("JKS");
    keystore.load(new ClassPathResource(mspKeyStore).getInputStream(),mspKeyStorePass.toCharArray());

    HostnameVerifier hostnameVerifier = (hostName, sslSession) -> true;

    SSLContext sslContext = SSLContextBuilder
        .create()
        .loadKeyMaterial(keystore, mspKeyStorePass.toCharArray())
        .loadTrustMaterial(keystore, null)
        .build();

    HttpClient client = HttpClients.custom()
        .setSSLContext(sslContext)
        .setSSLHostnameVerifier(hostnameVerifier)
        .build();

    return new RestTemplate(new HttpComponentsClientHttpRequestFactory(client));
  }

  @Bean
  @Qualifier(value=CommonConstant.NOOP_REST)
  public RestTemplate noopRestTemplate() throws GlobalApiException, NoSuchAlgorithmException,
  KeyStoreException, KeyManagementException {

    RestTemplate restTemplate = null;

    SSLContextBuilder builder = new SSLContextBuilder();
    builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
    SSLConnectionSocketFactory sslConnectionSocketFactory =
        new SSLConnectionSocketFactory(builder.build(), NoopHostnameVerifier.INSTANCE);
    Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
        .register("http", new PlainConnectionSocketFactory())
        .register("https", sslConnectionSocketFactory).build();

    PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
    cm.setMaxTotal(100);
    CloseableHttpClient httpclient = HttpClients.custom()
        .setSSLSocketFactory(sslConnectionSocketFactory).setConnectionManager(cm).build();

    HttpComponentsClientHttpRequestFactory requestFactory =
        new HttpComponentsClientHttpRequestFactory();
    requestFactory.setHttpClient(httpclient);

    restTemplate = new RestTemplate(requestFactory);

    return restTemplate;
  }
}