package com.income.ms.api.core.aspect;

import org.aspectj.lang.annotation.Pointcut;

public class JoinPointConfig {

  @Pointcut("controllerLayerExecution() || smControllerLayerExecution()")
  public void allControllerExecution(){}

  @Pointcut("controllerLayerExecution() || serviceLayerExecution()")
  public void allLayerExecution(){}

  @Pointcut("serviceLayerExecution() || smServiceLayerExecution()")
  public void allServiceExecution(){}

  @Pointcut("execution(* com.income.ms.api.*.*.*.controller.*.get*(..))")
  public void controllerLayerExecution(){}

  @Pointcut("execution(* com.income.ms.api.*.*.*.service.*.get*(..))")
  public void serviceLayerExecution(){}

  @Pointcut("execution(* com.income.ms.api.*.*.controller.*.*(..))")
  public void smControllerLayerExecution(){}

  @Pointcut("execution(* com.income.ms.api.*.*.service.*.*(..))")
  public void smServiceLayerExecution(){}

  @Pointcut("@annotation(com.income.ms.api.core.aspect.TrackTime)")
  public void trackTimeAnnotation(){}
}
