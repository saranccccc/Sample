package com.income.ms.api.core.config.mq;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLSocketFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.income.ms.api.core.constant.CommonConstant;

/**
 * Provides the SSL configuration for all the MQ service calls.
 *
 * @author Vinod Dampuru
 * @version 1.0
 * @since 2018-03-27
 */
@Component
@ConditionalOnClass(name = CommonConstant.GELS_DM_OBJ)
public class SslSocketFactory {

  private Resource keyStore;
  private String keyStorePassword;

  /**
   * This returns is used to create the instance of SSLSocketFactory.
   *
   * @return SSLSocketFactory This returns instance of SSLSocketFactory.
   * @throws KeyStoreException This throws KeyStoreException
   */
  public SSLSocketFactory createSocketFactory()
      throws KeyStoreException, NoSuchAlgorithmException, CertificateException,
      IOException, UnrecoverableKeyException, KeyManagementException {

    java.security.KeyStore keyStore = java.security.KeyStore.getInstance("JKS");
    keyStore.load(getKeyStore().getInputStream(),
        getKeyStorePassword().toCharArray());

    java.security.KeyStore trustStore = java.security.KeyStore.getInstance("JKS");
    trustStore.load(getKeyStore().getInputStream(), null);

    javax.net.ssl.TrustManagerFactory trustManFactory = javax.net.ssl.TrustManagerFactory
        .getInstance(javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm());

    javax.net.ssl.KeyManagerFactory keyManagerFactory = javax.net.ssl.KeyManagerFactory
        .getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
    trustManFactory.init(trustStore);

    keyManagerFactory.init(keyStore, getKeyStorePassword().toCharArray());
    javax.net.ssl.SSLContext sslContext = javax.net.ssl.SSLContext.getInstance("SSL");// SSLv3

    sslContext.init(keyManagerFactory.getKeyManagers(), trustManFactory.getTrustManagers(),
        null);
    return sslContext.getSocketFactory();
  }

  public Resource getKeyStore() {
    return keyStore;
  }

  public String getKeyStorePassword() {
    return keyStorePassword;
  }

  public void setKeyStore(Resource keyStore) {
    this.keyStore = keyStore;
  }

  public void setKeyStorePassword(String keyStorePassword) {
    this.keyStorePassword = keyStorePassword;
  }
}