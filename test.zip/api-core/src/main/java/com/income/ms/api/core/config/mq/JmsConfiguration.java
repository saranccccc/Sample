package com.income.ms.api.core.config.mq;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.jms.JMSException;
import org.apache.camel.component.jms.JmsComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.exception.GlobalApiException;

@Configuration
@ConditionalOnClass(name = CommonConstant.GELS_DM_OBJ)
public class JmsConfiguration {

  @Autowired
  private SslSocketFactory sslSocketFactory;

  @Autowired
  private MqDetailsConfig mqDetailsConfig;

  @Bean
  public ClassPathResource createKeyStore() {
    return new ClassPathResource(mqDetailsConfig.getKeyStore());
  }

  /**
   * This returns is used to create the instance of SslSocketFactory.
   *
   * @return SslSocketFactory This returns instance of SslSocketFactory.
   */
  @Bean
  public SslSocketFactory createSocketFactory() {
    sslSocketFactory.setKeyStorePassword(mqDetailsConfig.getKeyStorePassword());
    sslSocketFactory.setKeyStore(createKeyStore());
    return sslSocketFactory;
  }

  /**
   * This returns is used to create the instance 1 of JmsComponent.
   *
   * @return JmsComponent This returns instance of JmsComponent.
   * @throws JMSException throws JMSException
   */
  @Bean
  public JmsComponent mqConnection1()
      throws GlobalApiException, UnrecoverableKeyException, KeyManagementException,
      KeyStoreException, NoSuchAlgorithmException, CertificateException, JMSException, IOException {
    JmsComponent jmsComponent = new JmsComponent();
    jmsComponent
    .setConnectionFactory(mqQueueConnectionFactory(mqDetailsConfig.getMqDetails().get(0)));
    return jmsComponent;
  }

  /**
   * This returns is used to create the instance 2 of JmsComponent.
   *
   * @return JmsComponent This returns instance of JmsComponent.
   * @throws JMSException throws JMSException
   */
  @Bean
  public JmsComponent mqConnection2()
      throws GlobalApiException, UnrecoverableKeyException, KeyManagementException,
      KeyStoreException, NoSuchAlgorithmException, CertificateException, JMSException, IOException {
    JmsComponent jmsComponent = new JmsComponent();
    jmsComponent
    .setConnectionFactory(mqQueueConnectionFactory(mqDetailsConfig.getMqDetails().get(1)));
    return jmsComponent;
  }

  /**
   * This returns is used to create the instance of MQQueueConnectionFactory.
   *
   * @return MQQueueConnectionFactory returns MQQueueConnectionFactory.
   * @throws JMSException throws JMSException
   */
  @Bean
  public MQQueueConnectionFactory mqQueueConnectionFactory(MqDetails mqDetails)
      throws GlobalApiException, JMSException, UnrecoverableKeyException, KeyManagementException,
      KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
    MQQueueConnectionFactory mqConFactory = new MQQueueConnectionFactory();

    mqConFactory.setTransportType(mqDetails.getTransportType());
    mqConFactory.setHostName(mqDetails.getHostName());
    mqConFactory.setPort(mqDetails.getPort());
    mqConFactory.setQueueManager(mqDetails.getQueueManager());
    mqConFactory.setChannel(mqDetails.getChannel());
    mqConFactory.setSSLCipherSuite(mqDetails.getSslCipherSuite());
    mqConFactory.setSSLSocketFactory(sslSocketFactory.createSocketFactory());

    return mqConFactory;
  }
}
