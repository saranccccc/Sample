package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;

import com.gel.ms.api.domain.AgentCustProfile;
import com.gel.ms.api.domain.BirthdayListView;
import com.gel.ms.api.domain.BirthdayListing;
import com.gel.ms.api.domain.Contact360;
import com.gel.ms.api.domain.CustAdditionalInfoForAgent;
import com.gel.ms.api.domain.CustAddressInfoForAgent;
import com.gel.ms.api.domain.CustBasicInfoForAgent;
import com.gel.ms.api.domain.CustContactInfoForAgent;
import com.gel.ms.api.domain.CustIdentificationInfoForAgent;
import com.gel.ms.api.domain.Customer360Information;
import com.gel.ms.api.domain.CustomerProfile;
import com.gel.ms.api.domain.CustomerProfileAdditionalInformation;
import com.gel.ms.api.domain.CustomerProfileAddressInformation;
import com.gel.ms.api.domain.CustomerProfileBasicInformation;
import com.gel.ms.api.domain.CustomerProfileContactInformation;
import com.gel.ms.api.domain.CustomerProfileEducationInformation;
import com.gel.ms.api.domain.CustomerProfileEmploymentInformation;
import com.gel.ms.api.domain.CustomerProfileHealthInformation;
import com.gel.ms.api.domain.CustomerProfileSummaryInformation;
import com.gel.ms.api.domain.PhListing;
import com.gel.ms.api.domain.PhListingInformation;
import com.gel.ms.api.domain.SearchContact;
import com.gel.ms.api.domain.SearchContactInformation;
import com.income.ms.api.core.exception.GlobalApiException;


public interface CustomerProfileService {

  /**
   * This will return additional information of customer.
   *
   * @return additional details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileAdditionalInformation getAdditionalInfo(CustomerProfile request)
      throws GlobalApiException;

  /**
   * This return the additional information of customer.
   *
   * @return additional information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustAdditionalInfoForAgent getAdditionalInfoByAgent(AgentCustProfile request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This will return address information of customer.
   *
   * @return address details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileAddressInformation getAddressInfo(CustomerProfile request)
      throws GlobalApiException;

  /**
   * This return the address information of customer by Agent.
   *
   * @return address information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustAddressInfoForAgent getAddressInfoByAgent(AgentCustProfile request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This return the basic information of customer.
   *
   * @return basic information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileBasicInformation getBasicInfo(CustomerProfile request) throws GlobalApiException;

  /**
   * This return the basic information of customer by Agent.
   *
   * @return basic information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustBasicInfoForAgent getBasicInfoByAgent(AgentCustProfile request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This return the Role information of agent.
   *
   * @param birthdayListView
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  BirthdayListing getBirthdayListing(BirthdayListView birthdayListView, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This return the contact information of customer.
   *
   * @return contact details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileContactInformation getContactInfo(CustomerProfile request)
      throws GlobalApiException;

  /**
   * This return the contact information of customer by Agent.
   *
   * @return contact information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustContactInfoForAgent getContactInfoByAgent(AgentCustProfile request,
      Map<String, String> header) throws GlobalApiException, IOException;


  /**
   * This returns Customer 360 information of customer by agent.
   *
   * @return customer 360 information
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  Customer360Information getCust360Information(Contact360 request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This return the education information of customer.
   *
   * @return Education details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileEducationInformation getEducationInfo(CustomerProfile request)
      throws GlobalApiException;

  /**
   * This return the employment information of customer.
   *
   * @return Employment details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileEmploymentInformation getEmploymentInfo(CustomerProfile request)
      throws GlobalApiException;

  /**
   * This return the health information of customer.
   *
   * @return Health details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileHealthInformation getHealthInfo(CustomerProfile request) throws GlobalApiException;

  /**
   * This return the identification information of customer by Agent.
   *
   * @return identification information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustIdentificationInfoForAgent getIdInfoByAgent(AgentCustProfile request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This will return policy holder list information.
   *
   * @return policy holder list information
   * @throws GlobalApiException - when any exception occurs it is thrown
   * @throws IOException - when IOException occurs it is thrown
   */
  PhListingInformation getPolicyHolderList(PhListing request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will return policy holder list information.
   *
   * @return policy holder list information
   * @throws GlobalApiException - when any exception occurs it is thrown
   * @throws IOException - when IOException occurs it is thrown
   */
  SearchContactInformation getSearchCustomerContact(SearchContact request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This return the health information of customer.
   *
   * @return Summary details of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CustomerProfileSummaryInformation getSummaryInfo(CustomerProfile request)
      throws GlobalApiException;
}
