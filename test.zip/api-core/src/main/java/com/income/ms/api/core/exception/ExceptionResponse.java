package com.income.ms.api.core.exception;

import com.gel.ms.api.domain.SystemInformation;

public class ExceptionResponse {

  private SystemInformation systemInformation;

  public SystemInformation getSystemInformation() {
    return systemInformation;
  }

  public void setSystemInformation(SystemInformation systemInformation) {
    this.systemInformation = systemInformation;
  }
}
