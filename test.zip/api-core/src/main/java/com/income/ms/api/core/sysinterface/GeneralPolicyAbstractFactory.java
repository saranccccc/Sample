package com.income.ms.api.core.sysinterface;

import com.income.ms.api.core.enums.SystemEnum;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.interfaces.GeneralPolicyService;

public abstract class GeneralPolicyAbstractFactory {

  public abstract GeneralPolicyService getGeneralPolicyService(SystemEnum systemEnum)
      throws GlobalApiException;

}
