package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;

import com.gel.ms.api.domain.InforcePolicy;
import com.gel.ms.api.domain.InforcePolicyInformation;
import com.income.ms.api.core.exception.GlobalApiException;

public interface HealthPolicyService {

  /**
   * This will return the policy details of customer.
   *
   * @return Policy details of a customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  InforcePolicyInformation getPolicyDetails(InforcePolicy inforcePolicy, Map<String, String> header)
      throws GlobalApiException, IOException;

}
