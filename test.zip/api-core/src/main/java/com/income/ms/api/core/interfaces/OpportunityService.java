package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;
import javax.validation.Valid;

import com.gel.ms.api.domain.CreateOpportunityInformation;
import com.gel.ms.api.domain.CreateOpportunityView;
import com.gel.ms.api.domain.OpportunityCountInformation;
import com.gel.ms.api.domain.OpportunityCountView;
import com.gel.ms.api.domain.OpportunityDetailsView;
import com.gel.ms.api.domain.OpportunitySummaryInformation;
import com.gel.ms.api.domain.OpportunitySummarySearch;
import com.gel.ms.api.domain.OppurtunityDetailsInformation;
import com.gel.ms.api.domain.UpdateOpportunityInformation;
import com.income.ms.api.core.exception.GlobalApiException;


public interface OpportunityService {

  /**
   * This will create opportunity.
   *
   * @param createOpportunity
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  CreateOpportunityInformation createOpportunity(CreateOpportunityView createOpportunity,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This will return Count information of Opportunity.
   *
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  OpportunityCountInformation getOpportunityCount(OpportunityCountView opportunityCount,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This will return details information of opportunity.
   *
   * @return details information of opportunity
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  OppurtunityDetailsInformation getOpportunityDetailsInfo(OpportunityDetailsView request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This will return summary information of opportunity.
   *
   * @return summary information of opportunity
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  OpportunitySummaryInformation getOpportunitySummaryInfo(OpportunitySummarySearch request,
      Map<String, String> header) throws GlobalApiException, IOException;

  /**
   * This will update opportunity.
   *
   * @param createOpportunity
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  UpdateOpportunityInformation updateOpportunity(@Valid CreateOpportunityView createOpportunity,
      Map<String, String> header) throws GlobalApiException, IOException;
}
