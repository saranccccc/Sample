package com.income.ms.api.core.aspect;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.apache.camel.ExchangeTimedOutException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.client.WebServiceIOException;

import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.enums.CountryEnum;
import com.income.ms.api.core.enums.SystemEnum;
import com.income.ms.api.core.exception.BackendSystemException;
import com.income.ms.api.core.exception.ExceptionConfigProperties;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.exception.InvalidHeadersException;
import com.income.ms.api.core.util.ApiUtility;

@Aspect
@Configuration
public class AroundAopAspect {

  private static final Logger LOGGER = LoggerFactory.getLogger(AroundAopAspect.class);

  @Autowired
  private ExceptionConfigProperties exceptionConfigProperties;

  @Around("com.income.ms.api.core.aspect.JoinPointConfig.allControllerExecution()")
  public Object allControllerAdvice(ProceedingJoinPoint joinPoint) throws Throwable {

    Object obj = null;
    String reqRefNumber = CommonConstant.EMPTY_STRING;
    String controllerName = joinPoint.getSignature().getDeclaringTypeName();
    String methodName = joinPoint.getSignature().getName();

    LOGGER.info("Begining of the Controller {} with the method {}", controllerName, methodName);

    try {

      for (Object object : joinPoint.getArgs()) {

        if (object instanceof Map) {
          LOGGER.info("Header parameters are {}", object);
          reqRefNumber = checkMandatoryHeaders((Map<String, String>) object);
        } else {
          LOGGER.debug("Request body parameters are {}", object);
        }
      }

      obj = joinPoint.proceed();

    } catch (ExchangeTimedOutException | WebServiceIOException exe) {

      LOGGER.error("Connection time out exception in {} with error code {} and the reqrefnumber {}",
          methodName, CommonConstant.TIMEOUT_ERROR_CODE, reqRefNumber, exe);

      throw new WebServiceIOException(CommonConstant.TIMEOUT_ERROR_CODE);

    } catch (BackendSystemException | InvalidHeadersException exe) {

      if (exe instanceof BackendSystemException) {
        BackendSystemException backendSysExe = (BackendSystemException) exe;
        LOGGER.error("Backend exception in {} with error code {} and the reqrefnumber {}",
            methodName, backendSysExe.getErrorCode(), reqRefNumber,
            backendSysExe.getErrorMessage());

        throw new BackendSystemException(backendSysExe.getErrorCode(),
            backendSysExe.getErrorMessage());
      } else if (exe instanceof InvalidHeadersException) {
        InvalidHeadersException invalidHeadersExe = (InvalidHeadersException) exe;
        LOGGER.error("Invalid headers exception in {} with error code {} and the reqrefnumber {}",
            methodName, invalidHeadersExe.getErrorCode(), reqRefNumber,
            invalidHeadersExe.getErrorMessage());

        throw new InvalidHeadersException(invalidHeadersExe.getErrorCode(),
            invalidHeadersExe.getErrorMessage());
      }
    } catch (Exception exe) {

      List<String> exceptionDetailsList = getExceptionDetailsList(methodName);

      if (exceptionDetailsList == null || exceptionDetailsList.isEmpty()) {
        exceptionDetailsList = new ArrayList<String>();
        exceptionDetailsList.add(CommonConstant.EXE_UNCAUGHT_CODE);
        exceptionDetailsList.add(CommonConstant.EXE_UNCAUGHT_DESC);
      }

      LOGGER.error("exception in {} with error code {} and the reqrefnumber {}", methodName,
          exceptionDetailsList.get(0), reqRefNumber, exe);

      throw new GlobalApiException(exceptionDetailsList.get(0), exceptionDetailsList.get(1));
    }

    LOGGER.info("End of the Controller {} with the method {} and the reqrefnumber {}",
        controllerName, methodName, reqRefNumber);

    return obj;
  }

  @Around("com.income.ms.api.core.aspect.JoinPointConfig.allServiceExecution()")
  public Object allServiceAdvice(ProceedingJoinPoint joinPoint) throws Throwable {

    String reqRefNumber = CommonConstant.EMPTY_STRING;
    for (Object object : joinPoint.getArgs()) {
      if (object instanceof Map) {
        Map<String, String> headers = (Map<String, String>) object;
        reqRefNumber = headers.get(CommonConstant.RRNO);
      }
    }

    LOGGER.info("Begining of the Service {} with the method {} and reqRefNumber {}",
        joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(),
        reqRefNumber);

    Object obj = joinPoint.proceed();

    LOGGER.info("End of the Service {} with the method {} and reqRefNumber {}",
        joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(),
        reqRefNumber);

    return obj;
  }

  private String checkMandatoryHeaders(Map<String, String> headers) throws InvalidHeadersException {

    String reqRefNumber = CommonConstant.EMPTY_STRING;
    if (!headers.containsKey(CommonConstant.COUNTRY_CODE)
        || headers.containsKey(CommonConstant.COUNTRY_CODE) && !CountryEnum.countryMap
        .containsKey(headers.get(CommonConstant.COUNTRY_CODE).toLowerCase())) {
      throw new InvalidHeadersException(CommonConstant.COUNTRY_MISS_CODE,
          CommonConstant.COUNTRY_MISS_DESC);
    }
    if (!headers.containsKey(CommonConstant.PROVIDER_CODE)
        || headers.containsKey(CommonConstant.PROVIDER_CODE) && !SystemEnum.systemMap
        .containsKey(headers.get(CommonConstant.PROVIDER_CODE).toLowerCase())) {
      throw new InvalidHeadersException(CommonConstant.PROVIDER_MISS_CODE,
          CommonConstant.PROVIDER_MISS_DESC);
    }

    if (headers.containsKey(CommonConstant.RRNO)) {
      reqRefNumber = headers.get(CommonConstant.RRNO);
    }

    return reqRefNumber;
  }

  private List<String> getExceptionDetailsList(String methodName) {

    Function<Entry<String, String>, List<String>> exceptionCreation =
        (Entry<String, String> entry) -> {
          List<String> exeDetails = new ArrayList<>();
          String[] errorCode = entry.getKey().split("_");

          exeDetails.add(errorCode[0]);
          exeDetails.add(entry.getValue());

          return exeDetails;
        };

        return exceptionConfigProperties.getExceptionDetailsMap().entrySet().stream()
            .filter(entry -> entry.getKey().contains(methodName)).map(exceptionCreation)
            .collect(Collectors.toList()).get(0);
  }

  @Around("com.income.ms.api.core.aspect.JoinPointConfig.trackTimeAnnotation()")
  public Object trackTime(ProceedingJoinPoint joinPoint) throws Throwable {
    long startTime = System.currentTimeMillis();

    Object obj = joinPoint.proceed();

    LOGGER.info("Time Taken by {} is {}", joinPoint.getSignature().getName(),
        ApiUtility.getTimeForExecution(startTime));

    return obj;
  }
}
