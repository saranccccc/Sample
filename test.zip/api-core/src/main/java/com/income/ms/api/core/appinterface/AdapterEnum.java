package com.income.ms.api.core.appinterface;

public enum AdapterEnum {

  SOAP, REST, MQ
}
