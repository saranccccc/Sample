/**
 *
 */
package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;
import javax.validation.Valid;
import org.apache.camel.ExchangeTimedOutException;

import com.gel.ms.api.domain.FpmsPolicyDetails;
import com.gel.ms.api.domain.LifePolicy360Information;
import com.gel.ms.api.domain.Policy360;
import com.gel.ms.api.domain.PolicyDetailsLife;
import com.gel.ms.api.domain.PolicyList;
import com.income.ms.api.core.exception.GlobalApiException;

/**
 * @author HCL Technologies
 *
 */
public interface LifePolicyService {

  /**
   * This returns the Beneficiary Information.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getBeneficiaryInfo(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Bonus Details.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getBonusDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Financial Details.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getFinancialDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Fund Details.
   *
   * @param Fund Details
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getFundDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Investment Details.
   *
   * @param Investment Details
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getInvestmentDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Life Assured Information.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getLifeAssuredInfo(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy 360 Details.
   *
   * @param policy360
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  LifePolicy360Information getPolicy360(Policy360 policy360, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Additional Information.
   *
   * @param policyDetailsLife
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyAdditionalInfo(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Basic Information.
   *
   * @param policyDetailsLife
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyBasicInfo(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Coverage Details.
   *
   * @param policyDetailsLife
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyCoverageDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Details.
   *
   * @return Policy Details
   * @throws GlobalApiException - when any exception occurs it is thrown
   * @throws IOException - when IOException occurs it is thrown
   */
  Object getPolicyDetails(FpmsPolicyDetails fpmsPolicyDetails, Map<String, String> header)
      throws GlobalApiException, IOException, ExchangeTimedOutException;

  /**
   * This returns the Policy List.
   *
   * @param policyList
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyList(PolicyList policyList, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Payment Summary Information.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyPaymentSummary(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Premium Info.
   *
   * @param policyDetailsLife
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyPremiumInfo(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Status Info.
   *
   * @param policyDetailsLife
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPolicyStatusInfo(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Premium Additional Details.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getPremiumAdditionalDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This returns the Policy Sum Assured Details.
   *
   * @param policyDetailsLife
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getSumAssuredDetails(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getTransactionInformation(@Valid PolicyDetailsLife policyDetailsLife,
      Map<String, String> header)  throws GlobalApiException, IOException;

  /**
   * This returns the Underwriting Status.
   *
   * @param policyDetailsLife
   * @param header
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getUnderwritingStatus(PolicyDetailsLife policyDetailsLife, Map<String, String> header)
      throws GlobalApiException, IOException;

}
