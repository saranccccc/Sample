package com.income.ms.api.core.config.mq;

import java.util.ArrayList;
import java.util.List;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.income.ms.api.core.constant.CommonConstant;

@Component
@ConfigurationProperties(prefix = "app")
@ConditionalOnClass(name = CommonConstant.GELS_DM_OBJ)
public class MqDetailsConfig {

  private final List<MqDetails> mqDetails = new ArrayList<>();
  private String keyStorePassword;
  private String keyStore;

  public String getKeyStore() {
    return keyStore;
  }

  public String getKeyStorePassword() {
    return keyStorePassword;
  }

  public List<MqDetails> getMqDetails() {
    return mqDetails;
  }

  public void setKeyStore(String keyStore) {
    this.keyStore = keyStore;
  }

  public void setKeyStorePassword(String keyStorePassword) {
    this.keyStorePassword = keyStorePassword;
  }
}
