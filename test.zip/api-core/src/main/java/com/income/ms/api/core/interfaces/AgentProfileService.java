package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;

import com.gel.ms.api.domain.AgentId;
import com.gel.ms.api.domain.AgentProfile;
import com.gel.ms.api.domain.AgentProfileAddressInformation;
import com.gel.ms.api.domain.AgentProfileBasicInformation;
import com.gel.ms.api.domain.AgentProfileContactInformation;
import com.gel.ms.api.domain.AgentProfileCpdInformation;
import com.gel.ms.api.domain.AgentProfileDetailedInformation;
import com.gel.ms.api.domain.AgentProfilePersonalInformation;
import com.gel.ms.api.domain.AgentProfileQualificationInformation;
import com.gel.ms.api.domain.AgentProfileRankInformation;
import com.gel.ms.api.domain.AgentRoleInformation;
import com.income.ms.api.core.exception.GlobalApiException;

/**
 * .
 *
 * @author HCL Technologies
 */

public interface AgentProfileService {

  /**
   * This return the Address information of agent.
   *
   * @return Address information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileAddressInformation getAddressInfo(AgentProfile agentProfile)
      throws GlobalApiException;

  /**
   * This return the basic information of agent.
   *
   * @return basic information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileBasicInformation getBasicInfo(AgentProfile agentProfile) throws GlobalApiException;

  /**
   * This return the Contact information of agent.
   *
   * @return Contact information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileContactInformation getContactInfo(AgentProfile agentProfile)
      throws GlobalApiException;

  /**
   * This return the Cpd information of agent.
   *
   * @return Cpd information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileCpdInformation getCpdInfo(AgentProfile agentProfile) throws GlobalApiException;

  /**
   * This return the detailed information of agent.
   *
   * @return detailed information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileDetailedInformation getDetailedInfo(AgentProfile agentProfile)
      throws GlobalApiException;

  /**
   * This return the Personal information of agent.
   *
   * @return personal information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfilePersonalInformation getPersonalInfo(AgentProfile agentProfile)
      throws GlobalApiException;

  /**
   * This return the Qualification information of agent.
   *
   * @return Qualification information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileQualificationInformation getQualificationInfo(AgentProfile agentProfile)
      throws GlobalApiException;

  /**
   * This return the Ranking information of agent.
   *
   * @return Ranking information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  AgentProfileRankInformation getRankInfo(AgentProfile agentProfile) throws GlobalApiException;

  /**
   * This return the Role information of agent.
   *
   * @return Role information of agent
   * @throws GlobalApiException - when any exception occurs it is thrown
   * @throws IOException
   */
  AgentRoleInformation getRoleInfo(AgentId agentId, Map<String, String> header)
      throws GlobalApiException, IOException;
}
