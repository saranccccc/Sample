package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;

import com.gel.ms.api.domain.FycSummaryInformation;
import com.gel.ms.api.domain.FycSummaryView;
import com.gel.ms.api.domain.GelacSummaryInformation;
import com.gel.ms.api.domain.GelacSummaryView;
import com.gel.ms.api.domain.MdrtSummaryInformation;
import com.gel.ms.api.domain.MdrtSummaryView;
import com.income.ms.api.core.exception.GlobalApiException;

public interface AwardsService {

  /**
   * This will return count information of FYC.
   *
   * @param fycCountView
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  FycSummaryInformation getFycSummaryInfo(FycSummaryView request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will return count information of GELAC.
   *
   * @return count information of GELAC
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  GelacSummaryInformation getGelacSummaryInfo(GelacSummaryView request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will return count information of MDRT.
   *
   * @return count information of MDRT
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  MdrtSummaryInformation getMdrtSummaryInfo(MdrtSummaryView request, Map<String, String> header)
      throws GlobalApiException, IOException;


}
