package com.income.ms.api.core.config;

import java.util.List;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DozerMapping {

  @Value("#{'${app.dozer.configFiles}'.split(',')}")
  private List<String> mappingFiles;

  /** Method used for dozer mapping configaration.
   *
   * @return
   */
  @Bean(name = "org.dozer.Mapper")
  public DozerBeanMapper dozerBean() {
    DozerBeanMapper dozerBean = new DozerBeanMapper();
    dozerBean.setMappingFiles(mappingFiles);
    return dozerBean;
  }
}
