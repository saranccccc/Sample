package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;

import com.gel.ms.api.domain.AgentCustProfile;
import com.gel.ms.api.domain.PolicyListInformation;
import com.income.ms.api.core.exception.GlobalApiException;


public interface CustomerPortfolioService {

  /**
   * This return the Policy list information of customer.
   *
   * @return additional information of customer
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  PolicyListInformation getPolicyList(AgentCustProfile request,
      Map<String, String> header) throws GlobalApiException, IOException;

}
