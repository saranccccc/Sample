package com.income.ms.api.core.config.mq;

public class MqDetails {

  private Integer transportType;
  private String hostName;
  private Integer port;
  private String queueManager;
  private String channel;
  private String sslCipherSuite;

  public String getChannel() {
    return channel;
  }

  public String getHostName() {
    return hostName;
  }

  public Integer getPort() {
    return port;
  }

  public String getQueueManager() {
    return queueManager;
  }

  public String getSslCipherSuite() {
    return sslCipherSuite;
  }

  public Integer getTransportType() {
    return transportType;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public void setHostName(String hostName) {
    this.hostName = hostName;
  }

  public void setPort(Integer port) {
    this.port = port;
  }

  public void setQueueManager(String queueManager) {
    this.queueManager = queueManager;
  }

  public void setSslCipherSuite(String sslCipherSuite) {
    this.sslCipherSuite = sslCipherSuite;
  }

  public void setTransportType(Integer transportType) {
    this.transportType = transportType;
  }

  @Override
  public String toString() {
    return "MqDetails [transportType=" + transportType + ", hostName=" + hostName + ", port=" + port
        + ", queueManager=" + queueManager + ", channel=" + channel + ", sslCipherSuite="
        + sslCipherSuite + "]";
  }

}
