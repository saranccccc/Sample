package com.income.ms.api.core.swagger;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.util.ApiUtility;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

  @Value("${app.swagger.title}")
  private String title;

  @Value("${app.swagger.desc}")
  private String desc;

  /**
   * This method will display swagger for Agent profile.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket agentProfile() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.AGT_PRO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.AGT_PRO_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for all services.
   *
   * @return
   */
  //@Bean
  public Docket apiInformation() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.GROUP_NAME)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.CORE_PACKAGE_EXACT))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Reports information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket awardsInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.AWARDS_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.REPORTS_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Opportunity information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket createOpportunityInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.CRE_OPP_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.OPP_PACK))
        .paths(ApiUtility.agentAwardsPaths(CommonConstant.CREATE)).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Customer claims.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.ACCIDENT_HEALTH)
  public Docket customerClaims() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.HEALTH_POL_CLA)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.CUS_CLA_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Agent profile.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_CUS)
  public Docket customerPortfolio() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.CUS_PORT)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.CUS_PORT_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }


  /**
   * This method will display swagger for Customer profile.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_CUS)
  public Docket customerProfile() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.CUS_PRO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.CUS_PRO_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  private ApiInfo generalInformation() {
    Contact contact = new Contact(CommonConstant.API_INFO_CONTACT_NAME,
        CommonConstant.API_INFO_CONTACT_URL, CommonConstant.API_INFO_CONTACT_EMAIL);

    return new ApiInfoBuilder().title(title).description(desc)
        .termsOfServiceUrl(CommonConstant.API_INFO_TERMS_OF_SERVICE_URL).contact(contact)
        .license(CommonConstant.API_INFO_LICENSE).licenseUrl(CommonConstant.API_INFO_LICENSE_URL)
        .version(CommonConstant.API_INFO_VERSION).build();
  }


  /**
   * This method will display swagger for General Insurance information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_GEN_INSURANCE)
  public Docket generalInsurance() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.GEN_INSURANCE)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.GI_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  public List<Parameter> getParameterList() {
    ParameterBuilder countryBuilder = new ParameterBuilder();
    ParameterBuilder systemBuilder = new ParameterBuilder();
    List<Parameter> aParameters = new ArrayList<Parameter>();

    countryBuilder.name(CommonConstant.COUNTRY_CODE).description(CommonConstant.COUNTRY_CODE)
    .modelRef(new ModelRef("string")).parameterType("header").required(true).build();

    systemBuilder.name(CommonConstant.PROVIDER_CODE).description(CommonConstant.PROVIDER_CODE)
    .modelRef(new ModelRef("string")).parameterType("header").required(true).build();

    aParameters.add(countryBuilder.build());
    aParameters.add(systemBuilder.build());

    return aParameters;
  }


  /**
   * This method will display swagger for Lead create information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket leadCreateInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.CRE_LEAD_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LEAD_PACK))
        .paths(ApiUtility.agentAwardsPaths(CommonConstant.CREATE)).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Lead information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket leadInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.LEAD_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LEAD_PACK))
        .paths(ApiUtility.agentAwardsPaths(CommonConstant.ENQUIRY)).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Lead update information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket leadUpdateInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.UPD_LEAD_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LEAD_PACK))
        .paths(ApiUtility.agentAwardsPaths(CommonConstant.UPDATE)).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for government scheme policy.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_LIFE)
  public Docket lifeGovtSchemePolicy() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.LIFE_GOVT_SCM)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LIFE_GOVT_SCM_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for government scheme policy.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_LIFE)
  public Docket lifeGovtSchemeProposal() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.LIFE_GOVT_SCM_PROP)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LIFE_GOVT_SCM_PACK_PROP))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Customer profile.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_LIFE)
  public Docket lifePolicy() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.LIFE)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LIFE_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Customer profile.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_LIFE)
  public Docket lifeProposal() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.LIFE_PROP)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.LIFE_PROP_PACK))
        .paths(PathSelectors.any()).build()
        .globalOperationParameters(getParameterList());
  }

  /**
   * This method will display swagger for Opportunity information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket opportunityInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.OPP_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.OPP_PACK))
        .paths(ApiUtility.agentAwardsPaths(CommonConstant.ENQUIRY)).build()
        .globalOperationParameters(getParameterList());
  }

  private List<ResponseMessage> responseMessageList() {
    final List<ResponseMessage> respMsg = new ArrayList<ResponseMessage>();
    respMsg
    .add(new ResponseMessageBuilder().code(HttpStatus.INTERNAL_SERVER_ERROR.value())
        .message(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase())
        .responseModel(new ModelRef(CommonConstant.ERROR)).build());
    respMsg.add(new ResponseMessageBuilder().code(HttpStatus.FORBIDDEN.value())
        .message(CommonConstant.FORBIDDEN).build());
    respMsg.add(new ResponseMessageBuilder().code(HttpStatus.NOT_FOUND.value())
        .message(CommonConstant.NOT_FOUND).build());
    respMsg.add(new ResponseMessageBuilder().code(HttpStatus.OK.value())
        .message(CommonConstant.OK).build());
    respMsg.add(new ResponseMessageBuilder().code(HttpStatus.BAD_REQUEST.value())
        .message(CommonConstant.BAD_REQUEST).build());
    return respMsg;
  }

  /**
   * This method will display swagger for Opportunity information.
   *
   * @return
   */
  @Bean
  @ConditionalOnProperty(name = CommonConstant.MSP_NAME_KEY,
  havingValue = CommonConstant.MSP_AGENT)
  public Docket updateOpportunityInfo() {
    return new Docket(DocumentationType.SWAGGER_2).groupName(CommonConstant.UPD_OPP_INFO)
        .apiInfo(generalInformation()).useDefaultResponseMessages(false)
        .globalResponseMessage(RequestMethod.GET, responseMessageList())
        .globalResponseMessage(RequestMethod.POST, responseMessageList())
        .globalResponseMessage(RequestMethod.PUT, responseMessageList()).select()
        .apis(RequestHandlerSelectors.basePackage(CommonConstant.OPP_PACK))
        .paths(ApiUtility.agentAwardsPaths(CommonConstant.UPDATE)).build()
        .globalOperationParameters(getParameterList());
  }
}
