
package com.income.ms.api.core.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.income.ms.api.core.appinterface.SoapServiceAdapter;
import com.income.ms.api.core.constant.CommonConstant;

@Configuration
@ConditionalOnClass(name = CommonConstant.CDH_DOM_OBJ)
public class SoapConfiguration {

  @Autowired
  private SoapServiceAdapter soapServiceAdapter;

  /** Method uised to marshall the IAA xml.
   *
   * @return
   */

  @Bean
  public Jaxb2Marshaller marshaller() {
    Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
    marshaller.setContextPath(CommonConstant.CDH_DOMAIN_PACKAGE);
    return marshaller;
  }

  /** Method uised to marshall the IAA xml.
   *
   * @return
   */

  @Bean
  public SoapServiceAdapter setMarshallerObjs(Jaxb2Marshaller marshaller) {
    soapServiceAdapter.setMarshaller(marshaller);
    soapServiceAdapter.setUnmarshaller(marshaller);
    return soapServiceAdapter;
  }

}
