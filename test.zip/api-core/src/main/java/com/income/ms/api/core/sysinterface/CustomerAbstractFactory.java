package com.income.ms.api.core.sysinterface;

import com.income.ms.api.core.enums.SystemEnum;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.interfaces.CustomerPortfolioService;
import com.income.ms.api.core.interfaces.CustomerProfileService;

public abstract class CustomerAbstractFactory {

  public abstract CustomerPortfolioService getCustomerPortfolioService(SystemEnum systemEnum)
      throws GlobalApiException;

  public abstract CustomerProfileService getCustomerProfileService(SystemEnum systemEnum)
      throws GlobalApiException;
}