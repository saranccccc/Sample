package com.income.ms.api.core.appinterface;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.util.ApiUtility;

@Service
public class RestServiceAdapter implements IAdapter {

  private static final Logger LOGGER = LoggerFactory.getLogger(RestServiceAdapter.class);

  @Autowired
  @Qualifier(value=CommonConstant.HTTP_REST)
  private RestTemplate httpRestTemplate;

  @Autowired
  @Qualifier(value=CommonConstant.HTTPS_REST)
  private RestTemplate httpsRestTemplate;

  @Override
  public Object processRequest(Object request) throws GlobalApiException {

    long startTime = System.currentTimeMillis();

    Map<String, Object> requestMap = (Map<String, Object>) request;
    ResponseEntity<String> responseString = null;

    String serviceUri = (String) requestMap.get(CommonConstant.REST_SERVICE_URI);
    HttpMethod httpMethod = (HttpMethod) requestMap.get(CommonConstant.HTTP_METHOD);
    HttpEntity<?> entity = (HttpEntity<?>) requestMap.get(CommonConstant.HTTP_ENTITY);

    if(serviceUri.contains(CommonConstant.HTTPS)) {
      responseString = httpsRestTemplate.exchange(serviceUri, httpMethod, entity, String.class);
    } else {
      responseString = httpRestTemplate.exchange(serviceUri, httpMethod, entity, String.class);
    }

    LOGGER.info("Time Taken by rest {} is {} and reqrefnumber {}", "processRequest",
        ApiUtility.getTimeForExecution(startTime), entity.getHeaders().get(CommonConstant.RRNO));

    return responseString;
  }

}
