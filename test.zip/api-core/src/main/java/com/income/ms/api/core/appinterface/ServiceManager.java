package com.income.ms.api.core.appinterface;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.income.ms.api.core.constant.CommonConstant;

@Service
public class ServiceManager {

  @Autowired
  private SoapServiceAdapter soapServiceAdapter;

  @Autowired
  private RestServiceAdapter restServiceAdapter;

  @Autowired
  private MQServiceAdapter mqAdapter;

  public IAdapter createAdapter(AdapterEnum interfaceEnum) {

    IAdapter iAdapter = null;
    switch (interfaceEnum) {
      case SOAP:
        iAdapter = soapServiceAdapter;
        break;
      case REST:
        iAdapter = restServiceAdapter;
        break;
      case MQ:
        iAdapter = mqAdapter;
        break;
      default: throw new IllegalArgumentException(CommonConstant.NO_ADAPTER_FOUND);
    }
    return iAdapter;
  }
}