package com.income.ms.api.core.appinterface;

import com.income.ms.api.core.exception.GlobalApiException;

public interface IAdapter {

  public Object processRequest(Object request) throws GlobalApiException;

}
