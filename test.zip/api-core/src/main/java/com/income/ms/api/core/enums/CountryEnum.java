package com.income.ms.api.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum CountryEnum {
  SG("sg")
  ;

  public static Map<String, CountryEnum> countryMap = new LinkedHashMap<String,CountryEnum>();

  static {
    for (int i = 0;i < values().length;i++) {
      countryMap.put(values()[i].value, values()[i]);
    }
  }

  private String value;

  private CountryEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
