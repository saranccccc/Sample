package com.income.ms.api.core.exception;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Collectors;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.ws.client.WebServiceIOException;

import com.gel.ms.api.domain.SystemInformation;
import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.util.ApiUtility;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

  /**
   * This method will return the System Information about all exceptions.
   *
   * @return
   */
  private ExceptionResponse createExceptionResponse(Date timestamp, String errorMessage,
      String details, String errorCode) {

    ExceptionResponse exceptionResponse = new ExceptionResponse();
    SystemInformation systemInformation = new SystemInformation();

    exceptionResponse.setSystemInformation(systemInformation);

    systemInformation
    .setTimestamp(new SimpleDateFormat(CommonConstant.DATE_FORMAT_1).format(timestamp));
    systemInformation.setErrorMessage(errorMessage);
    systemInformation.setDetails(details);
    systemInformation.setErrorCode(errorCode);

    return exceptionResponse;

  }

  /**
   * This method will handle all exceptions.
   *
   * @return
   */
  @ExceptionHandler(Exception.class)
  public final ResponseEntity<Object> handleAllException(Exception exception, WebRequest request) {

    ExceptionResponse exceptionResponse = createExceptionResponse(new Date(),
        CommonConstant.EMPTY_STRING, CommonConstant.EMPTY_STRING, null);

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * This method handles the Backend system Exception.
   *
   * @return
   */
  @ExceptionHandler(BackendSystemException.class)
  public final ResponseEntity<Object> handleBackendSystemException(BackendSystemException exeption,
      WebRequest request) {

    ExceptionResponse exceptionResponse = createExceptionResponse(new Date(),
        exeption.getErrorMessage(), CommonConstant.EMPTY_STRING, exeption.getErrorCode());

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.BAD_REQUEST);
  }

  /**
   * This method handles the Global API Exception.
   *
   * @return
   */
  @ExceptionHandler(GlobalApiException.class)
  public final ResponseEntity<Object> handleGlobalApiException(GlobalApiException exeption,
      WebRequest request) {

    ExceptionResponse exceptionResponse = createExceptionResponse(new Date(),
        exeption.getErrorMessage(), CommonConstant.EMPTY_STRING, exeption.getErrorCode());

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.BAD_REQUEST);
  }

  /**
   * This method handle Illegal arguments exception.
   *
   * @return
   */
  @ExceptionHandler(IllegalArgumentException.class)
  public final ResponseEntity<Object> handleIllegalArgumentException(
      IllegalArgumentException exception, WebRequest request) {

    ExceptionResponse exceptionResponse = createExceptionResponse(new Date(),
        exception.getMessage(), CommonConstant.EMPTY_STRING, null);

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.BAD_REQUEST);
  }

  /**
   * This method handles the Invalid headers Exception.
   *
   * @return
   */
  @ExceptionHandler(InvalidHeadersException.class)
  public final ResponseEntity<Object> handleInvalidHeadersException(
      InvalidHeadersException exeption, WebRequest request) {

    ExceptionResponse exceptionResponse = createExceptionResponse(new Date(),
        exeption.getErrorMessage(), CommonConstant.EMPTY_STRING, exeption.getErrorCode());

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.BAD_REQUEST);
  }

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException exception, HttpHeaders headers, HttpStatus status,
      WebRequest request) {

    ExceptionResponse exceptionResponse =
        createExceptionResponse(new Date(), CommonConstant.VALIDATION_FAILED,
            exception.getBindingResult().getFieldErrors().stream()
            .map((FieldError fieldError) -> fieldError.getDefaultMessage())
            .collect(Collectors.joining(",")),
            CommonConstant.VALIDATION_ERROR_CODE);

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.BAD_REQUEST);
  }

  /**
   * This method handles the WebService IO Exception.
   *
   * @return
   */
  @ExceptionHandler(WebServiceIOException.class)
  public final ResponseEntity<Object> handleWebServiceIOException(WebServiceIOException exeption,
      WebRequest request) {

    ExceptionResponse exceptionResponse = createExceptionResponse(new Date(),
        CommonConstant.TIMEOUT_ERROR_CODE, CommonConstant.EMPTY_STRING,CommonConstant.TIMEOUT_ERROR_DESCRIPTION);

    return new ResponseEntity<>(exceptionResponse, ApiUtility.createResponseHeaders(request),
        HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
