package com.income.ms.api.core.sysinterface;

import com.income.ms.api.core.enums.SystemEnum;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.interfaces.LifePolicyService;
import com.income.ms.api.core.interfaces.LifeProposalService;

public abstract class LifePolicyAbstractFactory {
  public abstract LifePolicyService getLifePolicyService(SystemEnum systemEnum) throws GlobalApiException;

  public abstract LifeProposalService getProposalService(SystemEnum systemEnum) throws GlobalApiException;
}