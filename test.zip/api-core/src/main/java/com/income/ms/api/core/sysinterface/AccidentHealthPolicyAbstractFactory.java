package com.income.ms.api.core.sysinterface;

import com.income.ms.api.core.enums.SystemEnum;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.interfaces.HealthPolicyService;

public abstract class AccidentHealthPolicyAbstractFactory {
  public abstract HealthPolicyService getHealthPolicyService(SystemEnum systemEnum) throws GlobalApiException;
}