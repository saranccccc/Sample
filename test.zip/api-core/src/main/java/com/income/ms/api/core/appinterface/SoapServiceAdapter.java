package com.income.ms.api.core.appinterface;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.util.ApiUtility;

@Service
public class SoapServiceAdapter extends WebServiceGatewaySupport implements IAdapter {

  private static final Logger LOGGER = LoggerFactory.getLogger(SoapServiceAdapter.class);

  @Value("${app.cdh.service}")
  private String cdhServiceUri;

  @Override
  public Object processRequest(Object payloadRequest) throws GlobalApiException {
    long startTime = System.currentTimeMillis();

    Object responseObject =
        getWebServiceTemplate().marshalSendAndReceive(cdhServiceUri, payloadRequest);

    LOGGER.info("Time Taken by {} is {}", "processRequest",
        ApiUtility.getTimeForExecution(startTime));

    return responseObject;
  }

}
