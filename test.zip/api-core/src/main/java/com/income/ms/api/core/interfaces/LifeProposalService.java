/**
 *
 */
package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;
import org.apache.camel.ExchangeTimedOutException;

import com.income.ms.api.core.exception.GlobalApiException;

/**
 * @author HCL Technologies
 *
 */
public interface LifeProposalService {

  /**
   *
   * @param Proposal list
   * @return
   * @throws GlobalApiException
   * @throws IOException
   */
  Object getProposalList(Object fpmsPolicyDetails, Map<String, String> header)
      throws GlobalApiException, IOException, ExchangeTimedOutException;

}
