package com.income.ms.api.core.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.request.WebRequest;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gel.ms.api.domain.SystemInformation;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.enums.SystemEnum;

import springfox.documentation.builders.PathSelectors;

public class ApiUtility {

  public static Predicate<String> agentAwardsPaths(String indicator) {

    List<Predicate<String>> basePaths = new ArrayList<>();

    if(CommonConstant.ENQUIRY.equals(indicator)) {
      basePaths.add(PathSelectors.ant(CommonConstant.COUNT));
      basePaths.add(PathSelectors.ant(CommonConstant.SUMMARY));
      basePaths.add(PathSelectors.ant(CommonConstant.DETAILS));
    } else if (CommonConstant.CREATE.equals(indicator)) {
      basePaths.add(PathSelectors.ant(CommonConstant.AWARDS_CREATE));
    } else if (CommonConstant.UPDATE.equals(indicator)) {
      basePaths.add(PathSelectors.ant(CommonConstant.AWARDS_UPDATE));
      basePaths.add(PathSelectors.ant(CommonConstant.UPDATE_LEAD_STATUS));
    }

    return Predicates.or(basePaths);
  }

  public static ObjectMapper createObjectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
    return objectMapper;
  }

  public static ObjectMapper createObjectMapperWithCaseInsensitive() {
    ObjectMapper objectMapper = createObjectMapper();
    objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    return objectMapper;
  }

  public static MultiValueMap<String, String> createResponseHeaders(Object headers) {

    MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
    String reqRefNumber = CommonConstant.EMPTY_STRING;

    if (headers instanceof Map) {
      Map<String, String> inputHeadersMap = (Map<String, String>) headers;

      if (inputHeadersMap.containsKey(CommonConstant.RRNO)) {
        reqRefNumber = inputHeadersMap.get(CommonConstant.RRNO);
      }
    } else if (headers instanceof WebRequest) {
      WebRequest inputWebRequest = (WebRequest) headers;
      reqRefNumber = inputWebRequest.getHeader(CommonConstant.RRNO);
    }

    headersMap.add(CommonConstant.RRNO_RES, reqRefNumber);

    return headersMap;
  }

  public static SystemInformation createSysInfo(String errorCode, String errorMsg,
      SystemInformation sysInfo) {
    sysInfo.setErrorCode(errorCode);
    sysInfo.setErrorMessage(errorMsg);
    sysInfo.setTimestamp(new SimpleDateFormat(CommonConstant.DATE_FORMAT_1).format(new Date()));
    return sysInfo;
  }

  public static HttpHeaders getHeadersInfo(Map<String, String> header) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.add(CommonConstant.RRNO, header.get(CommonConstant.RRNO));
    headers.add(CommonConstant.PROVIDER_CODE, header.get(CommonConstant.PROVIDER_CODE));
    headers.add(CommonConstant.COUNTRY_CODE, header.get(CommonConstant.COUNTRY_CODE));
    headers.add(CommonConstant.CLIENT_CODE, header.get(CommonConstant.CLIENT_CODE));
    headers.add(CommonConstant.TIMESTAMP, header.get(CommonConstant.TIMESTAMP));
    return headers;
  }

  public static SystemEnum getSysEnum(Map<String, String> headers) {
    return SystemEnum.systemMap.get(headers.get(CommonConstant.PROVIDER_CODE).toLowerCase());
  }

  public static long getTimeForExecution(Long startTime) {
    return (System.currentTimeMillis() - startTime) / 1000;
  }

  public static String replaceNullWithEmpty(Object object) throws IOException {
    ObjectMapper mapper = createObjectMapper();
    String responseString = mapper.writeValueAsString(object);
    return responseString.replaceAll("null", "\"\"");
  }
}
