package com.income.ms.api.core.appinterface;

import java.util.Map;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.income.ms.api.core.constant.CommonConstant;
import com.income.ms.api.core.exception.GlobalApiException;
import com.income.ms.api.core.util.ApiUtility;

@Service
public class MQServiceAdapter implements IAdapter {

  private static final Logger LOGGER = LoggerFactory.getLogger(MQServiceAdapter.class);

  @Autowired
  private CamelContext camelContext;

  @Override
  public Object processRequest(Object request) throws GlobalApiException {

    long startTime = System.currentTimeMillis();

    Map<String, Object> requestMap = (Map<String, Object>) request;

    Exchange responseExchange = camelContext.createProducerTemplate()
        .send(CommonConstant.MQ_END_POINT, (Exchange requestExchange) -> {
          requestExchange.getIn().setHeader(CommonConstant.MQ_REQUEST_FROM,
              requestMap.get(CommonConstant.MQ_REQUEST_FROM));
          requestExchange.getIn().setBody(requestMap.get(CommonConstant.MQ_INPUT));
        });

    LOGGER.info("Time Taken by mq {} is {}", "processRequest",
        ApiUtility.getTimeForExecution(startTime));

    return responseExchange;
  }

}
