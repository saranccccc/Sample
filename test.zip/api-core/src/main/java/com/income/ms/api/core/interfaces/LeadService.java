package com.income.ms.api.core.interfaces;

import java.io.IOException;
import java.util.Map;

import com.gel.ms.api.domain.AgentId;
import com.gel.ms.api.domain.CreateLead;
import com.gel.ms.api.domain.CreateLeadInformation;
import com.gel.ms.api.domain.LeadCountInformation;
import com.gel.ms.api.domain.LeadDetails;
import com.gel.ms.api.domain.LeadDetailsInformation;
import com.gel.ms.api.domain.LeadStatusView;
import com.gel.ms.api.domain.LeadSummaryInformation;
import com.gel.ms.api.domain.LeadSummarySearch;
import com.gel.ms.api.domain.UpdateLeadInformation;
import com.gel.ms.api.domain.UpdateLeadStatus;
import com.income.ms.api.core.exception.GlobalApiException;

public interface LeadService {

  /**
   * This will create lead.
   *
   * @return CreateLeadInformation - information of lead
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  CreateLeadInformation createLead(CreateLead createLead, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will return count information of lead.
   *
   * @return count information of lead
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  LeadCountInformation getLeadCountInfo(AgentId request, Map<String, String> header)
      throws GlobalApiException, IOException;


  /**
   * This return the details of lead.
   *
   * @return details of lead
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  LeadDetailsInformation getLeadDetailsInfo(LeadDetails request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will return summary information of lead.
   *
   * @return summary information of lead
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  LeadSummaryInformation getLeadSummaryInfo(LeadSummarySearch request, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will update lead information.
   *
   * @return CreateLeadInformation - information of lead
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  UpdateLeadInformation updateLead(CreateLead createLead, Map<String, String> header)
      throws GlobalApiException, IOException;

  /**
   * This will update lead status.
   *
   * @return updateLeadStatus - information of lead
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  UpdateLeadStatus updateLeadStatus(LeadStatusView request, Map<String, String> header)
      throws GlobalApiException, IOException;

}
