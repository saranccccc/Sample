package com.income.ms.api.core.interfaces;

public interface Services {

  public interface System {

    public interface Cdh {

      String CUSTOMER_SERVICE = "cdhAgentProfileServiceImpl";
      String AGENT_PRO_SERVICE = "cdhAgentProfileServiceImpl";
      String CUST_PORTFOLIO_SERVICE = "cdhCustomerPortfolioServiceImpl";
      String LIFE_POLICY_SERVICE = "cdhPolicyServiceImpl";
      String LIFE_PROPOSAL_SERVICE = "cdhPropServiceImpl";
      String GENERAL_POLICY_SERVICE = "cdhGenPoliServiceImpl";
    }

    public interface Crm {

      String LEAD_SERVICE = "crmLeadServiceImpl";
      String OPPORTUNITY_SERVICE = "crmOpportunityServiceImpl";
      String AWARDS_SERVICE = "crmAwardsServiceImpl";
      String AGENT_PRO_SERVICE = "crmAgentProfileServiceImpl";

    }

    public interface Fpms {

      String LIFE_POLICY_SERVICE = "fpmsPolServiceImpl";
      String LIFE_PROPOSAL_SERVICE = "fpmsPropServiceImpl";
    }

    public interface Lif {

      String LIF_POLICY_SERVICE = "lifPolicyServiceImpl";

    }

    public interface Lis {

      String LIS_POLICY_SERVICE = "lisPolicyServiceImpl";

    }

    public interface Mcs {

      String MCS_POLICY_SERVICE = "mcsPolicyServiceImpl";

    }

    public interface Navisys {

      String NAV_POLICY_SERVICE = "navPolicyServiceImpl";
      String LIFE_PROPOSAL_SERVICE = "navPropServiceImpl";

    }

    String NO_SERVICE_FOUND = "Service not found for the system";
  }
}
