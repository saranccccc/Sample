package com.income.ms.api.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum SystemEnum {

 
  LIS("lis"),
  LIF("lif"),
  CID("cid"),
  CRM("crm"),;

  public static Map<String, SystemEnum> systemMap = new LinkedHashMap<String,SystemEnum>();

  static {
    for (int i = 0;i < values().length;i++) {
      systemMap.put(values()[i].value, values()[i]);
    }
  }

  private String value;

  private SystemEnum(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
