package com.gel.ms.api.customer.util;

/**
 *
 * @author HCL Technologies
 */

import java.util.List;
import java.util.stream.Collectors;
import org.dozer.DozerConverter;
import com.gel.ms.api.core.constant.CommonConstant;
import com.gel.ms.api.customer.profile.constant.CustomerProfileConstant;
import com.gel.ms.api.domain.cdh.PartyRegistrations;

@SuppressWarnings("rawtypes")
public class PartyRegistrationsCustomConverter extends DozerConverter {

  /**
   * PartyRegistrationsCustomConverter.
   *
   */
  @SuppressWarnings("unchecked")
  public PartyRegistrationsCustomConverter() {
    super(PartyRegistrations.class, String.class);
  }

  /**
   * convertFrom.
   *
   */
  @Override
  public Object convertFrom(Object source, Object destination) {
    return null;
  }

  /**
   * This return the String from PartyRegistrations.
   *
   * @return String information of agent
   */
  @Override
  public Object convertTo(Object source, Object destination) {
    List<PartyRegistrations> partyRegs = (List<PartyRegistrations>) source;

    String parameter = getParameter();
    String response = CommonConstant.EMPTY_STRING;

    if (CustomerProfileConstant.CUSTOMER_SEGMENT.equalsIgnoreCase(parameter)) {
      response =  partyRegs.stream()
          .filter(partyReg -> partyReg.getPartyRegistration() != null
          && partyReg.getPartyRegistration().getTypeName() != null
          && partyReg.getPartyRegistration().getTypeName().getValue()
          .equalsIgnoreCase(CustomerProfileConstant.SEGMENTATION_CODE))
          .map(partyReg -> partyReg.getPartyRegistration().getIdNumber().getValue())
          .collect(Collectors.joining());
    }

    if (CustomerProfileConstant.ID_NUMBER.equalsIgnoreCase(parameter)) {
      response =  partyRegs.stream()
          .filter(partyReg -> partyReg.getPartyRegistration() != null
          && partyReg.getPartyRegistration().getRegistrationType() != null)
          .map(partyRegistration -> partyRegistration.getPartyRegistration().getIdNumber()
              .getValue())
          .collect(Collectors.joining());
    }

    if (CustomerProfileConstant.ID_TYPE.equalsIgnoreCase(parameter)) {
      response =  partyRegs.stream()
          .filter(partyReg -> partyReg.getPartyRegistration() != null
          && partyReg.getPartyRegistration().getRegistrationType() != null)
          .map(partyRegistration -> partyRegistration.getPartyRegistration().getRegistrationType()
              .getEnumeration().getDescription().getValue())
          .collect(Collectors.joining());
    }

    return response;
  }

}
