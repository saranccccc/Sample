package com.income.ms.api.customer.portfolio.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.gel.ms.api.domain.AgentCustProfile;
import com.gel.ms.api.domain.constant.DomainConstant;

/**
 * .
 *
 * @author
 */

@Component
public class Contact360PolicyListValidator implements Validator {

  /**
   * Tags this validator for the class AgentCustProfile.
   * @return AgentCustProfile - object
   */
  @Override
  public boolean supports(Class<?> clazz) {
    return AgentCustProfile.class.isAssignableFrom(clazz);
  }

  /**
   * Validate the incoming object.
   */
  @Override
  public void validate(Object inputObj, Errors err) {

    ValidationUtils.rejectIfEmptyOrWhitespace(err, DomainConstant.ID_TYPE, null,
        DomainConstant.ID_TYPE_MSG);
    ValidationUtils.rejectIfEmptyOrWhitespace(err, DomainConstant.ID_NUMBER, null,
        DomainConstant.ID_NUMBER_MSG);
    ValidationUtils.rejectIfEmptyOrWhitespace(err, DomainConstant.AGT_ID, null,
        DomainConstant.AGT_ID_MSG);
    ValidationUtils.rejectIfEmptyOrWhitespace(err, DomainConstant.PAGE_NO, null,
        DomainConstant.PAGE_NO_MSG);
    ValidationUtils.rejectIfEmptyOrWhitespace(err, DomainConstant.RECORDS_FETCH, null,
        DomainConstant.RECORDS_FETCH_MSG);
  }

}
