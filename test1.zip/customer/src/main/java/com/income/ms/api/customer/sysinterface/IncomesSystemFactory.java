package com.income.ms.api.customer.sysinterface;

/**
 *
 * @author 
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import com.gel.ms.api.core.enums.SystemEnum;
import com.gel.ms.api.core.exception.GlobalApiException;
import com.gel.ms.api.core.interfaces.CustomerPortfolioService;
import com.gel.ms.api.core.interfaces.CustomerProfileService;
import com.gel.ms.api.core.interfaces.Services;
import com.gel.ms.api.core.sysinterface.CustomerAbstractFactory;

@Component
public class IncomesSystemFactory extends CustomerAbstractFactory {

  @Qualifier(Services.System.Cdh.CUSTOMER_SERVICE)
  @Autowired
  private CustomerProfileService cdhCustomerProfileServiceImpl;

  @Qualifier(Services.System.Cdh.CUST_PORTFOLIO_SERVICE)
  @Autowired
  private CustomerPortfolioService cdhCustomerPortfolioServiceImpl;

  /**
   * This return the Instance of the CustomerPortfolioService based on the system.
   *
   * @return CustomerPortfolioService - service based on the system
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  @Override
  public CustomerPortfolioService getCustomerPortfolioService(SystemEnum systemEnum)
      throws GlobalApiException {
    switch (systemEnum) {
      case CDH:
        return cdhCustomerPortfolioServiceImpl;

      default:
        throw new GlobalApiException(Services.System.NO_SERVICE_FOUND,
            Services.System.NO_SERVICE_FOUND);
    }
  }

  /**
   * This return the Instance of the CustomerProfileService based on the system.
   *
   * @return CustomerProfileService - service based on the system
   * @throws GlobalApiException - when any exception occurs it is thrown
   */
  @Override
  public CustomerProfileService getCustomerProfileService(SystemEnum systemEnum)
      throws GlobalApiException {
    switch (systemEnum) {
      case CDH:
        return cdhCustomerProfileServiceImpl;

      default:
        throw new GlobalApiException(Services.System.NO_SERVICE_FOUND,
            Services.System.NO_SERVICE_FOUND);
    }
  }
}
