package com.income.ms.api.customer.portfolio.controller;

/**
 *
 * @author 
 */

import java.io.IOException;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.gel.ms.api.core.aspect.TrackTime;
import com.gel.ms.api.core.constant.CommonConstant;
import com.gel.ms.api.core.enums.SystemEnum;
import com.gel.ms.api.core.exception.GlobalApiException;
import com.gel.ms.api.core.util.ApiUtility;
import com.gel.ms.api.customer.portfolio.constant.CustomerPortfolioConstant;
import com.gel.ms.api.customer.portfolio.validator.Contact360PolicyListValidator;
import com.gel.ms.api.customer.sysinterface.GelsSystemFactory;
import com.gel.ms.api.domain.AgentCustProfile;
import com.gel.ms.api.domain.PolicyListInformation;
import com.gel.ms.api.domain.constant.DomainConstant;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@Api(description = CustomerPortfolioConstant.API_VALUE, tags = CustomerPortfolioConstant.API_DESC)
@RequestMapping(produces = CommonConstant.PRODUCES)
public class CustomerPortfolioController {

  @Autowired
  private GelsSystemFactory gelsSystemFactory;

  @Autowired
  private Contact360PolicyListValidator polListValidator;

  /**
   * This return the policy listing information of customer by agent.
   *
   * @return policy listing information
   * @throws GlobalApiException - when any exception occurs it is thrown
   * @throws IOException - when IOException occurs it is thrown
   */
  @ApiOperation(value = CustomerPortfolioConstant.API_AGT_PLCY_VAL,
      nickname = CustomerPortfolioConstant.GET_PL_INFO)
  @PostMapping(path = CustomerPortfolioConstant.PLCY_LIST_URL_AGT)
  @TrackTime
  public ResponseEntity<String> getPolicyList(@Valid @RequestBody AgentCustProfile request,
      @ApiIgnore @RequestHeader(required = false) Map<String, String> header)
          throws GlobalApiException, IOException {

    SystemEnum sysEnum = ApiUtility.getSysEnum(header);
    PolicyListInformation response =
        gelsSystemFactory.getCustomerPortfolioService(sysEnum).getPolicyList(request, header);
    return getResponseEntity(header, response);
  }

  /**
   * .
   *
   * @param header - request headers
   * @param response - response object
   * @return
   */
  private ResponseEntity<String> getResponseEntity(Map<String, String> header, Object response)
      throws GlobalApiException, IOException {
    return new ResponseEntity<>(ApiUtility.replaceNullWithEmpty(response),
        ApiUtility.createResponseHeaders(header), HttpStatus.OK);
  }


  /**
   * This will bind the validator for the object DomainConstant.AGT_CUST_PRO.
   *
   */
  @InitBinder(DomainConstant.AGT_CUST_PRO)
  protected void initBinder(WebDataBinder binder) {
    binder.setValidator(polListValidator);
  }
}
