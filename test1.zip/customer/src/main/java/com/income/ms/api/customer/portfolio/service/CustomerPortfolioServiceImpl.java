package com.income.ms.api.customer.portfolio.service;

/**
 *
 * @author 
 */
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gel.ms.api.core.appinterface.AdapterEnum;
import com.gel.ms.api.core.appinterface.ServiceManager;
import com.gel.ms.api.core.constant.CommonConstant;
import com.gel.ms.api.core.exception.GlobalApiException;
import com.gel.ms.api.core.interfaces.CustomerPortfolioService;
import com.gel.ms.api.core.interfaces.Services;
import com.gel.ms.api.core.util.ApiUtility;
import com.gel.ms.api.customer.portfolio.constant.CustomerPortfolioConstant;
import com.gel.ms.api.customer.profile.constant.CustomerProfileConstant;
import com.gel.ms.api.domain.AgentCustProfile;
import com.gel.ms.api.domain.PolicyListInformation;

@Service
@CacheConfig(cacheNames = CommonConstant.CACHE_NAME)
@Qualifier(Services.System.Cdh.CUST_PORTFOLIO_SERVICE)
public class CustomerPortfolioServiceImpl implements CustomerPortfolioService {

  @Value("${app.cdhrest.service}")
  private String cdhServiceUri;

  @Autowired
  private ServiceManager serviceManager;

  private String getCdhServiceUriInfo(String serviceUri) {
    return new StringBuilder().append(cdhServiceUri).append(serviceUri).toString();
  }

  /**
   * This return the policy listing information of customer by agent.
   *
   * @return policy listing information
   * @throws GlobalApiException - when any exception occurs it is thrown
   * @throws IOException - when IOException occurs it is thrown
   */
  @Override
  @Cacheable(value = CustomerPortfolioConstant.API_AGT_PLCY_VAL)
  public PolicyListInformation getPolicyList(AgentCustProfile request, Map<String, String> header)
      throws GlobalApiException, IOException {

    ObjectMapper mapper = ApiUtility.createObjectMapperWithCaseInsensitive();

    request.setRole(CustomerProfileConstant.ROLE_DR);
    request.setResourceIndicator(CustomerProfileConstant.POLICY_LIST_INFO);
    request.setLifePolicyIndicator(CommonConstant.YES);
    request.setLifeProposalIndicator(CommonConstant.NO);
    request.setGiPolicyIndicator(CommonConstant.YES);

    HttpEntity<AgentCustProfile> entity =
        new HttpEntity<AgentCustProfile>(request, ApiUtility.getHeadersInfo(header));

    ResponseEntity<String> response =
        getResponse(getCdhServiceUriInfo(CustomerProfileConstant.CUSTOMER360_URL), entity);
    return mapper.readValue(response.getBody(), PolicyListInformation.class);
  }

  private ResponseEntity<String> getResponse(String serviceUri, HttpEntity<?> entity)
      throws GlobalApiException {
    Map<String, Object> requestMap = new LinkedHashMap<String, Object>();
    requestMap.put(CommonConstant.REST_SERVICE_URI, serviceUri);
    requestMap.put(CommonConstant.HTTP_METHOD, HttpMethod.POST);
    requestMap.put(CommonConstant.HTTP_ENTITY, entity);

    return (ResponseEntity<String>) serviceManager.createAdapter(AdapterEnum.REST)
        .processRequest(requestMap);
  }
}
