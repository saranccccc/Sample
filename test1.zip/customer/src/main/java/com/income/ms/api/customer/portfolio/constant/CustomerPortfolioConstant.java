package com.income.ms.api.customer.portfolio.constant;

import com.income.ms.api.core.constant.CommonConstant;
/**
 * .
 *
 * @author 
 */

public class CustomerPortfolioConstant {

  public static final String SERVICE_PATH = CommonConstant.COUNTRY + "/v1/customer/portfolio";
  public static final String PLCY_LIST_URL_AGT = SERVICE_PATH + "/policy/list";

  public static final String API_VALUE = "Portfolio";
  public static final String API_DESC = "Customer";

  public static final String API_AGT_PLCY_VAL = "Policy Listing Information by Agent";

  public static final String GET_PL_INFO = "getPolicyListInformation";
}
