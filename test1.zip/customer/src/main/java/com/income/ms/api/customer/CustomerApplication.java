package com.income.ms.api.customer;

/**
 *
 * @author 
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import com.gel.ms.api.core.constant.CommonConstant;

@SpringBootApplication
@EnableCaching
@ComponentScan(CommonConstant.CORE_PACKAGE)
public class CustomerApplication {

  /**
   * This is the main class for the application and loads the application context.
   *
   */
  public static void main(String[] args) {
    SpringApplication.run(CustomerApplication.class, args);
  }
}
